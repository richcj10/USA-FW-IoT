#ifndef __MQTT_APP_H
#define __MQTT_APP_H

void ICACHE_FLASH_ATTR mqtt_app_init();

#endif