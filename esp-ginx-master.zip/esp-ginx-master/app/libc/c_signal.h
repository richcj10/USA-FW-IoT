#ifndef _C_SIGNAL_H_
#define _C_SIGNAL_H_

#include <signal.h>

#endif /* _C_SIGNAL_H_ */
