#ifndef DNS_H
#define DNS_H

void ICACHE_FLASH_ATTR init_dns();

#endif