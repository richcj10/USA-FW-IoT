gvChart
=======

jQuery plugin for generating Google Charts from well-formed tables
